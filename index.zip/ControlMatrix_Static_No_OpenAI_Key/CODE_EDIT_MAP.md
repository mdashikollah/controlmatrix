# Code Edit Map

| Area | File | Search target |
|---|---|---|
| Main application UI and logic | `index.html` | View IDs, form IDs and JavaScript functions |
| PWA metadata | `manifest.webmanifest` | `name`, `short_name`, `description` |
| Offline cache | `sw.js` | `CACHE`, `ASSETS` |
| Cloudflare Pages configuration | `wrangler.toml` | project name and output directory |
| Deployment and setup | `README.md` | `Deploy on Cloudflare Pages` |
| Security guidance | `SECURITY.md` | static/offline controls |

The live operational-brief function and OpenAI secret configuration were removed from this revision.
