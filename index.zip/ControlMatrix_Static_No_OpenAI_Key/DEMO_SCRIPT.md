# Demo Script

1. Start the synthetic judge demo.
2. Show the high-risk document deferral, its owner, backup owner, due date and escalation information.
3. Update a controlled field and enter the mandatory update note.
4. Open the audit trail and demonstrate old value, new value, user, timestamp and note.
5. Show task, project and deferral registers, backup/export controls and offline PWA behaviour.
6. Explain that GPT-5.6 supported requirements and workflow design, while Codex curated and implemented the production-ready application.
7. State that the revised deployment is fully static and needs no API key.
