# ProjectOS Sentinel / ControlMatrix

An offline-first progressive web application for task, project and document-deferral governance.

## Current deployment profile

This revised package is fully static and does **not** call the OpenAI API or require an `OPENAI_API_KEY`. It can be deployed directly to Cloudflare Pages, GitHub Pages, Netlify or any static host.

Core features include task and BAU management, project tracking, document-deferral control, primary and backup ownership, team workspaces, follow-up and reminder drafts, local and IndexedDB backup, JSON/CSV import and export, optional user-configured workspace sync, permission controls, and tamper-evident audit records.

## Deploy on Cloudflare Pages

1. Upload this folder or connect the repository.
2. Use no build command.
3. Set the output directory to the repository root (`.`).
4. Deploy. No environment variable or secret is required.

## Local testing

Serve the folder through a local static server, for example:

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080`. Opening `index.html` directly also works for most features, but service-worker installation requires HTTP/HTTPS.

## Offline and data model

Operational data is stored in the browser and mirrored to IndexedDB where available. Export a JSON or administrator CSV backup before clearing browser data or changing devices. Optional workspace synchronization remains available only when the user supplies their own compatible sync API base URL.

## Build Week development evidence

GPT-5.6 supported requirements analysis, product reasoning, workflow design and documentation. Codex was used to curate and implement the project, review the codebase, improve the controlled workflows and prepare deployment-ready files. The earlier experimental live operational-brief endpoint was removed from this revised static package so the deployed application no longer needs an API key.

## Security

Do not enter confidential production data into a public demonstration deployment. Use synthetic records for judging and demonstrations. See `SECURITY.md` for additional controls.
