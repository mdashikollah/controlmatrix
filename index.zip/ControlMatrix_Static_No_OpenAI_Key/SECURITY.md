# Security

This revised package is a static offline-first PWA and contains no OpenAI API integration, API key, or server-side secret requirement.

- Keep production and confidential information out of public demo deployments.
- Browser storage is device- and browser-profile-specific.
- Export encrypted or administrator backups before clearing browser data.
- Optional workspace synchronization should only point to an organization-approved HTTPS endpoint.
- Review access roles, owner controls and audit evidence before operational use.
- Never commit passwords, tokens or private endpoints to the repository.
